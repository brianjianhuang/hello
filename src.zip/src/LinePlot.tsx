import * as d3 from "d3";
import { useD3 } from "./useD3";
import { Data, Layout } from "./Plot";

function paddedExtent<T>(data: T[], accessor: (d:T) => number, pct = 0.1) {
  const [min, max] = d3.extent(data, accessor);
  const range = max - min;
  return [
    min - range * pct,
    max + range * pct
  ];
}

export const LinePlot = (
  props: { data: Data[]; setData?: (d: Data[]) => void; layout: Layout },
) => {

  const ref = useD3((svg) => {
    const xScale = d3.scaleLinear()
      .domain(paddedExtent(props.data, (d) => d.x, 0.05))
      .range([props.layout.left, props.layout.width - props.layout.right]);

    const yScale = d3.scaleLinear()
      .domain([0, 105])
      .range([props.layout.height - props.layout.bottom, props.layout.top]);

    const xAxis: d3.Selection<SVGGElement, unknown, null, undefined> = svg
      .select("#xAxis");

    const yAxis: d3.Selection<SVGGElement, unknown, null, undefined> = svg
      .select("#yAxis");

    xAxis.transition().call(d3.axisBottom(xScale));
    yAxis.transition().call(d3.axisLeft(yScale).ticks(10).tickFormat(d => d + "%"));

    const yGrid: d3.Selection<SVGGElement, unknown, null, undefined> = svg.select("#yGrid");

    yGrid.selectAll("line").data(yScale.ticks())
      .join("line")
      .transition()
      .attr("fill", "none")
      .attr("stroke", "gray")
      .attr("stroke-dasharray", "3,3")
      .attr("x1", props.layout.left)
      .attr("x2", props.layout.width - props.layout.right)
      .attr("y1", d => yScale(d))
      .attr("y2", d => yScale(d));

    // draw actual line plot
    const line = d3.line<Data>()
      .x((d) => xScale(d.x))
      .y((d) => yScale(d.y));

    svg.select("#data").select("path").data([props.data])
        .attr("fill", "none")
        .attr("stroke", "steelblue")
        .attr("stroke-width", 2)
        .join(
            (enter) => enter,
            (update) => update.transition().attr("d", line),
            (exit) => exit.remove(),
        );

    // draw point so we can show it when ony i point is brushed
    let points = svg.select("#data")
      .selectAll<SVGCircleElement, Data>("circle")
      .data(props.data)
      .join(
        (enter) =>
          enter.append("circle")
            .attr("r", 3)
            .attr("fill", "steelblue")
            .attr("id", (_, i) => i)
            .attr("cx", d => xScale(d.x))
            .attr("cy", d => yScale(d.y))
            .attr("class", "cursor-pointer"),
        (update) =>
          update.transition()
            .attr("id", (_, i) => i)
            .attr("cx", d => xScale(d.x))
            .attr("cy", d => yScale(d.y)),
        (exit) => exit.remove(),
      );

   // Initial hidden hover circle
  const hoverCircle = svg.append("circle")
    .attr("r", 0)
    .attr("fill", "black")
    .attr("stroke", "black")
    .attr("stroke-width", 1.5)
    .style("pointer-events", "none");

     const hoverVerticalLine = svg.append("line")
       .attr("stroke", "gray")
       .style("pointer-events", "none")
       .attr("opacity", 0);

     const hoverHorizontalLine = svg.append("line")
       .attr("stroke", "gray")
       .style("pointer-events", "none")
       .attr("opacity", 0);

     const tooltip = d3.select("body")
       .append("div")
       .attr("class", "tooltip")
       .style("opacity", 0);

     // Mouse overlay rectangle
     svg.append("rect")
       .attr("fill", "transparent")
       .attr("width", props.layout.width)
       .attr("height", props.layout.height)
       .on("mousemove", onMouseMove)
       .on("mouseleave", onMouseLeave);

     // Find nearest point helper
     function getNearestPoint(mouseX) {
       const xValue = xScale.invert(mouseX);
       let nearest = props.data[0];
       let minDist = Infinity;

       props.data.forEach(d => {
         const dist = Math.abs(d.x - xValue);
         if (dist < minDist) {
           minDist = dist;
           nearest = d;
         }
       });

       return nearest;
     }

     // Mouse move handler
     function onMouseMove(event) {
       const [mx] = d3.pointer(event);
       const nearest = getNearestPoint(mx);

       const cx = xScale(nearest.x);
       const cy = yScale(nearest.y);

       hoverCircle
         .attr("cx", cx)
         .attr("cy", cy)
         .attr("r", 7);

       hoverVerticalLine
         .attr("x1", cx)
         .attr("x2", cx)
         .attr("y1", 0)
         .attr("y2", props.layout.height - 20)
         .attr("opacity", 1);

       hoverHorizontalLine
         .attr("x1", 30)
         .attr("x2", props.layout.width)
         .attr("y1", cy)
         .attr("y2", cy)
         .attr("opacity", 1);

       tooltip
         .style("opacity", 1)
         .html(`Name: ${nearest.label} <br>Value:  ${nearest.y} `)
         .style("left", event.pageX + 12 + "px")
         .style("top", event.pageY - 20 + "px");
     }

        function onMouseLeave() {
        hoverCircle.transition().attr("r", 0);
        hoverVerticalLine.attr("opacity", 0);
        hoverHorizontalLine.attr("opacity", 0);
        tooltip.style("opacity", 0);
        }

  }, [props.data, props.layout]);

  return (
    <svg
      ref={ref}
      width={props.layout.width + 50 }
      height={props.layout.height   }
      viewBox={`0 0 ${props.layout.width} ${props.layout.height}`}
    >
      <g>
        <g
          id="yGrid"
        />
        <g id="data">
          <path />
        </g>
        <g
          id="xAxis"
          transform={`translate(0, ${props.layout.height - props.layout.bottom})`}
        />
        <g
          id="yAxis"
          transform={`translate(${props.layout.left}, 0)`}
        />
      </g>
    </svg>
  );
};
