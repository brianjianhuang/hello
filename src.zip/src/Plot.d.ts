export type Data = {
  x: number;
  y: number;
  label: string;
};

export type Layout = {
  width: number;
  height: number;
  top: number;
  bottom: number;
  left: number;
  right: number;
};

