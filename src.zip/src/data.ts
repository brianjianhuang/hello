

const rawData = [
{ "user": "Rm6vnmNPRvz", "value": 11, "category": 7 },
{ "user": "cB0hC", "value": 9, "category": 7 },
{ "user": "xFapEXx9", "value": 12, "category": 9 },
{ "user": "stHdo1TV", "value": 6, "category": 10 },
{ "user": "NlUafWkpjduC3", "value": 10, "category": 7 },
{ "user": "e7DwVrmJ", "value": 7, "category": 6 },
{ "user": "uEOJsO", "value": 6, "category": 14 },
{ "user": "zlTNlewuDKcRl", "value": 13, "category": 8 },
{ "user": "BQlhXiIHXUo42I", "value": 12, "category": 14 },
{ "user": "SO6lM", "value": 5, "category": 5 },
{ "user": "kn3LTrlFv6", "value": 5, "category": 11 },
{ "user": "rFKwr3vSxco3K7", "value": 7, "category": 9 },
{ "user": "1gzvu", "value": 11, "category": 14 },
{ "user": "BL ymOGU", "value": 13, "category": 10 },
{ "user": "vwEH33kh8 Bhny", "value": 6, "category": 5 } ];


type RawItem = {
  user: string;
  value: number;
  category: number;
};

let total = 0;
const grouped = rawData.reduce((acc, item) => {
    const cat = item.category;
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    total = total + item.value;
    return acc;
}, {} as Record<number, RawItem[]> );

export const chartData = Object.entries(grouped)
         .map(([category, arr]) => ({
            x: Number(category),
            y: Math.round( (arr.reduce((a, item) => a + item.value, 0) / total) * 10000) /100 ,
            label: arr.map(item => item.user).join(",")
         }))
         .sort((a,b) => a.x - b.x );

