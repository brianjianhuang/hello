import * as d3 from "d3";
import { useState, useEffect } from "react";
import { LinePlot } from "./LinePlot";
import { SummaryLine } from "./SummaryLine";
import { Data, Layout } from "./Plot";
import { chartData } from "./data"

const layout = {
    width: 600,
    height: 400,
    left: 25,
    right: 0,
    top: 0,
    bottom: 25,
};

const summaryLayout = {
    width: 600,
    height: 30,
    left: 25,
    right: 0,
    top: 5,
    bottom: 5,
};

function App() {
  const [data, setData] = useState<Data[]>(chartData);

   const handleBrush = (subset) => {
       if (subset && subset.length > 0) {
          setData(subset);
       } else {
          setData(chartData);
       }
   }

  return (
    <div>
        <h3>Percent Value vs Category</h3>
        <div>
          <LinePlot data={data} layout={layout} />
        </div>
        <div>
          <SummaryLine data={chartData} layout={summaryLayout} onBrush={handleBrush} />
        </div>
    </div>
  );
}

export default App;
