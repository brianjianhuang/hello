import * as d3 from "d3";
import { D3BrushEvent } from "d3";
import { useD3 } from "./useD3";
import { Data, Layout } from "./Plot";
import { DependencyList, useEffect, useRef, useState } from "react";

export const SummaryLine = (
  props: { data: Data[]; layout: Layout; onBrush : (value: any) => void },
) => {
  const ref = useD3((svg) => {
    const xScale = d3.scaleLinear()
      .domain(d3.extent(props.data, (d) => d.x).map((x) => x ?? 0))
      .range([props.layout.left, props.layout.width - props.layout.right]);

    const yScale = d3.scaleLinear()
      .domain(d3.extent(props.data, (d) => d.y).map((y) => y ?? 0))
      .range([props.layout.height - props.layout.bottom, props.layout.top]);

    const line = d3.line<Data>()
      .x((d) => xScale(d.x))
      .y((d) => yScale(d.y));

    svg.select("#data").select("path").data([props.data])
        .attr("fill", "none")
        .attr("stroke", "steelblue")
        .attr("stroke-width", 2)
      .join(
        (enter) => enter,
        (update) => update.transition().attr("d", line),
        (exit) => exit.remove(),
      );

    const brushed = ({selection} : D3BrushEvent<any>) => {
        if (!selection) {
            return;
        }
        const [[x0, y0], [x1, y1]] = selection as [[number, number], [number, number]];
        // Find all points inside brush box
        const selected = props.data.filter(d => {
            const px = xScale(d.x);
            const py = yScale(d.y);
            return px >= x0 && px <= x1 && py >= y0 && py <= y1;
        });
        props.onBrush(selected)
    }

    const brush = d3.brush()
        .extent([[0, 0], [props.layout.width, props.layout.height]])
        .on("brush end", brushed);

    svg.append("g")
        .call(brush);

  }, [props.data, props.layout]);

  return (
    <svg
      ref={ref}
      width={props.layout.width + 50}
      height={props.layout.height}
      viewBox={`0 0 ${props.layout.width} ${props.layout.height}`}
    >
        <g id="data">
          <path />
        </g>
    </svg>
  );
};
